---
name: master-command
description: >-
  Master blueprint and autonomous pipeline for building, optimizing, and deploying fast, high-converting,
  SEO-optimized local business websites to Cloudflare Pages, syncing Spaceship DNS, and submitting to Google Search Console.
---

# Master Command: Local Website Development & Autonomous Deployment Pipeline

## 0. Mandatory Pre-Creation Intake Questionnaire
Before generating code or creating site pages, you MUST collect:
1. **Website / Business Name**
2. **Website Address** (Physical Address / Service Area & Domain URL)
3. **Website Phone Number**
4. **Category** (Primary GMB Category / Business Niche)
5. **Operating Hours**
6. **Target Keywords**
7. **Competitor URLs**

*Strict Rule*: Do not generate custom site pages until all 7 details are provided. Once provided, run the pipeline autonomously end-to-end without pausing.

---

## 1. Core Architecture & Assets
- **Performance**: Mobile-first, LCP < 2.5s, CLS < 0.1, INP < 200ms.
- **Mandatory Asset Existence**: `assets/css/styles.css` and `assets/js/main.js` MUST always exist and be written to disk.
- **Strict SVG Constraints**: Every `<svg>` MUST have explicit inline `width` and `height` attributes and inlined critical CSS width/height constraints in `<head>`.
- **Conversion Features**: High-converting sticky mobile click-to-call bar (`tel:...`), desktop header phone CTA with live status dot.
- **E-E-A-T & Trust**: Hero section, quantified proof matrix, origin story, authentic team/license badges, local review carousel.
- **Technical SEO**: Single semantic `<h1>`, clean heading hierarchy, `<picture>` image tags with lazy loading (except hero with `fetchpriority="high"`), canonical tags, `sitemap.xml`, and valid JSON-LD LocalBusiness schema.

---

## 2. Infrastructure & Automation Pipeline
1. **DNS & Registrar**: Connect Spaceship API (`PUT /v1/domains/{domain}/nameservers`) and Cloudflare API (`POST /client/v4/zones`).
2. **Edge & Pages**: Deploy static assets to Cloudflare Pages via Wrangler (`npx wrangler pages deploy sites/<site-name> --project-name <site-name> --commit-dirty=true`).
3. **Domain & Routing**: Attach custom domains (`domain.com` and `www.domain.com`), configure proxied CNAME records, Edge redirect/rewrite rules.
4. **Email Routing**: Auto-enable Cloudflare Email Routing forwarding `info@` and catch-all `*@` to `anis@agesoftsolutions.com`.
5. **Google Search Console**: Programmatically register site and submit `sitemap.xml` using `scripts/gsc_manager.py` with `config.json`.
6. **Live Endpoint Verification**: Verify all live endpoints (200 OK for HTML, `styles.css`, `main.js`, and SSL active).
